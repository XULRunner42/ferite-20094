
void dot_write_function( FeriteFunction *function, FILE *output );
void dot_write_class( FeriteClass *klass, FILE *output );
void dot_write_namespace( FeriteNamespace *ns, FILE *output );
void dot_write_script( FeriteScript *script, char *path );
